# auth-service

## To DO 
* Exception handling
* Logging
* Unit tests